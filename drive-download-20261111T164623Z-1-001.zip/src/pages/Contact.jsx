import React from "react";

function Contact() {
  function handleSubmit(event) {
    event.preventDefault();
    alert("Your message has been sent successfully!");
    event.target.reset();
  }

  return (
    <section className="section contact">
      <h1>Contact Us</h1>
      <p>Email: foodhub@example.com</p>
      <p>Phone: +961 70 000 000</p>

      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Your Name" required />
        <input type="email" placeholder="Your Email" required />
        <textarea placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </section>
  );
}

export default Contact;