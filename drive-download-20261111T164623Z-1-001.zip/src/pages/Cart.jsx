import React, { useContext } from "react";
import { CartContext } from "../context/CartContext";

function Cart() {
  const { cart, removeFromCart, updateQuantity, total } =
    useContext(CartContext);

  return (
    <section className="section">
      <h1>My Cart</h1>

      {cart.length === 0 ? (
        <p>Your cart is empty. Go to Menu and add some food!</p>
      ) : (
        <>
          {cart.map((item) => (
            <div className="cart-item" key={item.id}>
              <div>
                <h3>{item.name}</h3>
                <p>${item.price} each</p>
              </div>

              <div className="quantity">
                <button onClick={() => updateQuantity(item.id, -1)}>
                  -
                </button>

                <span>{item.quantity}</span>

                <button onClick={() => updateQuantity(item.id, 1)}>
                  +
                </button>
              </div>

              <strong>${item.price * item.quantity}</strong>

              <button
                className="remove-button"
                onClick={() => removeFromCart(item.id)}
              >
                Remove
              </button>
            </div>
          ))}

          <h2 className="total">Total: ${total.toFixed(2)}</h2>
          <button
            className="main-button"
            onClick={() => alert("Thank you for your order!")}
          >
            Place Order
          </button>
        </>
      )}
    </section>
  );
}

export default Cart;