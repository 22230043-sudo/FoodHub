import React, { useState } from "react";
import FoodCard from "../components/FoodCard";

const foods = [
  {
    id: 1,
    name: "Classic Burger",
    price: 8,
    category: "Burgers",
    description: "Juicy beef burger with fresh vegetables.",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600"
  },
  {
    id: 2,
    name: "Margherita Pizza",
    price: 12,
    category: "Pizza",
    description: "Fresh mozzarella, tomato and basil.",
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600"
  },
  {
    id: 3,
    name: "Chicken Burger",
    price: 9,
    category: "Burgers",
    description: "Crispy chicken with special sauce.",
    image: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=600"
  },
  {
    id: 4,
    name: "Pepperoni Pizza",
    price: 14,
    category: "Pizza",
    description: "Pizza topped with cheese and pepperoni.",
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=600"
  },
  {
    id: 5,
    name: "Caesar Salad",
    price: 7,
    category: "Salads",
    description: "Fresh lettuce, parmesan and Caesar dressing.",
    image: "https://images.unsplash.com/photo-1546793665-c74683f339c1?w=600"
  },
  {
    id: 6,
    name: "Greek Salad",
    price: 8,
    category: "Salads",
    description: "Fresh vegetables, olives and feta cheese.",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600"
  }
];

function Menu() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const filteredFoods = foods.filter((food) => {
    return (
      food.name.toLowerCase().includes(search.toLowerCase()) &&
      (category === "All" || food.category === category)
    );
  });

  return (
    <section className="section">
      <h1>Our Menu</h1>
      <p>Choose your favorite meal.</p>

      <input
        className="search-input"
        type="text"
        placeholder="Search food..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="categories">
        {["All", "Burgers", "Pizza", "Salads"].map((item) => (
          <button
            key={item}
            className={category === item ? "active" : ""}
            onClick={() => setCategory(item)}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="food-grid">
        {filteredFoods.map((food) => (
          <FoodCard key={food.id} food={food} />
        ))}
      </div>

      {filteredFoods.length === 0 && <p>No food found.</p>}
    </section>
  );
}

export default Menu;