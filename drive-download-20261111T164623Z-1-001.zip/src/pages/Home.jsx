import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div>
      <section className="hero">
        <div className="hero-content">
          <p className="tagline">WELCOME TO FOODHUB</p>
          <h1>Delicious Food, Delivered Fresh.</h1>
          <p>
            Enjoy your favorite meals made with fresh ingredients
            and delivered right to your door.
          </p>
          <Link to="/menu" className="main-button">
            Order Now
          </Link>
        </div>
      </section>

      <section className="section">
        <h2>Why Choose FoodHub?</h2>

        <div className="features">
          <div>
            <h3>Fresh Food</h3>
            <p>We use fresh and quality ingredients.</p>
          </div>

          <div>
            <h3>Fast Service</h3>
            <p>Your favorite meals, prepared with care.</p>
          </div>

          <div>
            <h3>Great Taste</h3>
            <p>Delicious meals for every moment.</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;