import React from "react";

function About() {
  return (
    <section className="section about">
      <h1>About FoodHub</h1>

      <p>
        FoodHub is a restaurant ordering system created to make
        ordering delicious food simple and convenient.
      </p>

      <p>
        Our goal is to provide customers with a variety of meals,
        easy ordering, and a great food experience.
      </p>
    </section>
  );
}

export default About;